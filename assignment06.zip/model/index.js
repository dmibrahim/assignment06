module.exports = {
    Car:require('./car-schema'),
    Image: require('./image-model')
}